#!/usr/bin/env python3
"""Verify actual deliverable bytes, provenance, native-alpha copies and baseline coverage."""
import collections
import csv
import hashlib
import json
from pathlib import Path

from PIL import Image

import catalog


def key(row):
    return catalog.safe_name(row['brand']).casefold(), catalog.safe_name(row['model']).casefold(), str(row['year'])


def main():
    root = catalog.ROOT
    baseline = catalog.rows_from_file(root / '_QUEUE' / 'HANDOFF_MERGED.csv')
    baseline_keys = {key(row) for row in baseline}
    progress = list(csv.DictReader((root / '_REPORTS' / 'IMAGE_PROGRESS.csv').open(encoding='utf-8')))
    progress_keys = [key(row) for row in progress]
    assert len(progress_keys) == len(set(progress_keys)), 'Duplicate model records in progress report'
    assert baseline_keys <= set(progress_keys), 'A supplied handoff model was lost'
    manifest, sources, native_count = [], [], 0
    image_hashes = collections.defaultdict(list)
    for source in sorted(root.glob('*/*/*/*/source.json')):
        metadata = json.loads(source.read_text())
        original = source.parent / metadata['source_original']
        assert source.parent == root / catalog.row_directory(metadata), f'Unexpected model directory: {source}'
        assert original.name in ('source_original.png', 'source_original.jpg'), f'Unexpected original: {original}'
        digest = hashlib.sha256(original.read_bytes()).hexdigest()
        assert digest == metadata['sha256'], f'Original checksum mismatch: {original}'
        assert metadata['verification_status'] == 'VISUALLY_VERIFIED_ORIGINAL' and metadata['view_verified'], f'Unreviewed image: {source}'
        assert metadata.get('visually_verified_at'), f'Missing visual-review date: {source}'
        assert metadata['source_page'].startswith('https://') and metadata['image_url'].startswith('https://'), f'Missing HTTPS provenance: {source}'
        with Image.open(original) as image:
            assert image.format == ('PNG' if original.suffix == '.png' else 'JPEG'), f'Extension/format mismatch: {original}'
            dimensions = image.size
            assert dimensions == (metadata['image_dimensions']['width'], metadata['image_dimensions']['height']), f'Dimension mismatch: {original}'
            image.verify()
        for field, filename in [('transparent','vehicle_transparent.png'),('preview','preview.png'),('mask_wrap','mask_wrap.png'),('mask_exclusions','mask_exclusions.png')]:
            asset = source.parent / filename
            assert bool(metadata.get(field)) == asset.is_file(), f'Claimed asset disagrees with filesystem: {asset}'
            if asset.is_file():
                with Image.open(asset) as image:
                    assert image.format == 'PNG' and image.size == dimensions, f'Asset format or alignment mismatch: {asset}'
                    image.verify()
        if metadata.get('transparent_origin') == 'manufacturer_supplied_png; unchanged bytes':
            for filename in ('vehicle_transparent.png','preview.png'):
                assert hashlib.sha256((source.parent / filename).read_bytes()).hexdigest() == digest, f'Native image bytes changed: {source.parent / filename}'
            with Image.open(original) as image:
                assert 'A' in image.getbands() and image.getchannel('A').getextrema() == (0,255), f'Native alpha missing: {original}'
            native_count += 1
        if metadata['status'] == 'READY':
            assert all(metadata.get(field) for field in ('transparent','mask_wrap','mask_exclusions','preview')), f'Incomplete model marked READY: {source}'
        else:
            assert metadata['status'] == 'NEEDS_MASK_REVIEW', f'Unexpected approved asset status: {source}'
        image_hashes[digest].append(str(source.relative_to(root)))
        sources.append(metadata)
        manifest.append({
            'brand':metadata['brand'],'model':metadata['model'],'year':metadata['year'],
            'generation':metadata.get('generation') or '', 'actual_view':metadata['view'],
            'source_original':str(original.relative_to(root)), 'width':dimensions[0], 'height':dimensions[1],
            'native_transparent':bool(metadata.get('transparent')), 'mask_wrap':bool(metadata.get('mask_wrap')),
            'mask_exclusions':bool(metadata.get('mask_exclusions')), 'preview':bool(metadata.get('preview')),
            'status':metadata['status'], 'source_page':metadata['source_page'], 'image_url':metadata['image_url'],
            'sha256':digest,'download_date':metadata['download_date'], 'visually_verified_at':metadata['visually_verified_at'],
        })
    assert {key(row) for row in sources} == {key(row) for row in progress if row.get('source_original')}, 'Approved assets and report disagree'
    columns = ['brand','model','year','generation','actual_view','source_original','width','height','native_transparent','mask_wrap','mask_exclusions','preview','status','source_page','image_url','sha256','download_date','visually_verified_at']
    catalog.write_csv(root / '_REPORTS' / 'ASSET_MANIFEST.csv', columns, manifest)
    result = {
        'audited_at':catalog.now(),'result':'PASS', 'baseline_records':len(baseline),
        'baseline_approved_originals':sum(key(row) in baseline_keys for row in sources),
        'additional_approved_variants':sum(key(row) not in baseline_keys for row in sources),
        'progress_records':len(progress),'verified_originals':len(sources), 'native_transparent_pngs':native_count,
        'mask_wrap_files':sum(row['mask_wrap'] for row in manifest),
        'mask_exclusions_files':sum(row['mask_exclusions'] for row in manifest),
        'preview_files':sum(row['preview'] for row in manifest),
        'ready_assets':sum(row['status']=='READY' for row in sources),
        'progress_status_counts':dict(collections.Counter(row['status'] for row in progress)),
        'approved_by_brand':dict(collections.Counter(row['brand'] for row in sources)),
        'duplicate_original_checksums':{digest:paths for digest,paths in image_hashes.items() if len(paths)>1},
        'checks':['all supplied models retained','progress keys unique','original checksums and formats','recorded dimensions','HTTPS provenance','actual visual-review records','claimed files exist','PNG dimensions align','native-alpha copies unchanged','no incomplete READY assets'],
        'scope':'File and provenance audit; source.json records visual review and remaining mask/generation limitations. Catalog remains progressive.',
    }
    catalog.write_json(root / '_REPORTS' / 'INTEGRITY_AUDIT.json', result)
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
