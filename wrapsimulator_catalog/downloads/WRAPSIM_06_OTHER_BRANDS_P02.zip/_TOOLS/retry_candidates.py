#!/usr/bin/env python3
"""Resume temporary failures from the handoff-derived queue, with bounded parallel HTTP retrieval."""
import argparse
import concurrent.futures
import json
from pathlib import Path
from urllib.parse import urlparse

import catalog


def retrieve(row):
    if (catalog.ROOT / catalog.row_directory(row) / 'source.json').exists():
        return None
    selected, errors = [], []
    try:
        for item in catalog.discover(row)[:16]:
            try:
                selected.append(catalog.candidate_download(row, item, catalog.ROOT / '_CANDIDATES' / catalog.row_directory(row)))
                if len(selected) == 2:
                    break
            except Exception as error:
                errors.append(urlparse(item['url']).hostname + ': ' + str(error)[:250])
        if not selected:
            raise ValueError('No suitable source downloaded. ' + '; '.join(errors[:4]))
        status, reason = 'PENDING_VISUAL_REVIEW', ''
    except Exception as error:
        status = 'BLOCKED_NETWORK' if any(x in str(error) for x in ('Tunnel connection failed', 'CLOUD_NETWORK_TEMPORARY')) else 'SOURCE_FETCH_FAILED'
        reason = str(error)[:650]
    return {**row, 'status': status, 'candidate_count': len(selected), 'reason': reason,
            'checked_at': catalog.now(), 'retry_errors': errors}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--temporary-failures-only', action='store_true')
    args = parser.parse_args()
    state_file = catalog.ROOT / '_REPORTS' / 'DOWNLOAD_STATE.json'
    initial = json.loads(state_file.read_text()) if state_file.exists() else []
    key = lambda row: (catalog.safe_name(row['brand']).casefold(), catalog.safe_name(row['model']).casefold(), str(row['year']))
    outcomes = {key(row): row for row in initial}
    rows = catalog.rows_from_file(args.input)
    if args.temporary_failures_only:
        rows = [row for row in rows if any(x in outcomes.get(key(row), {}).get('reason', '') for x in ('HTTP Error 503', 'CLOUD_NETWORK_TEMPORARY'))]
    rows = [row for row in rows if not (catalog.ROOT / catalog.row_directory(row) / 'source.json').exists()]
    print(f'Retrying {len(rows)} existing handoff models; 4 HTTP workers; no automatic approval', flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        jobs = [executor.submit(retrieve, row) for row in rows]
        for job in concurrent.futures.as_completed(jobs):
            outcome = job.result()
            if not outcome:
                continue
            # Only the main thread writes the shared state and reports.
            outcomes[key(outcome)] = outcome
            catalog.write_json(state_file, list(outcomes.values()))
            catalog.reports(list(outcomes.values()))
            print(f"{outcome['brand']} {outcome['model']}: {outcome['status']} ({outcome['candidate_count']}) {outcome['reason'][:140]}", flush=True)


if __name__ == '__main__':
    main()
