#!/usr/bin/env python3
"""Download publisher-supplied imagery; retain originals and require honest visual review.

No paid image APIs, no image generation, no system changes, no server deployment.
Downloads and all persistent output stay inside the selected catalog directory.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import io
import json
import os
from pathlib import Path
import re
import shutil
import sys
from datetime import datetime, timezone
from html.parser import HTMLParser
from http.client import HTTPException
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse, urlsplit, urlunsplit, quote, parse_qsl, urlencode
from urllib.request import Request, urlopen
import zipfile

from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
OFFICIAL = {
    'Porsche': ('porsche.com', 'porschepictures.flowcenter.de'),
    'Mercedes-Benz': ('mercedes-benz.com', 'mercedes-benz.it'),
    'Audi': ('audi-mediacenter.com', 'audi.com', 'audi.it'),
    'BMW': ('bmwgroup.com', 'bmw.com', 'bmw.it', 'bmw.scene7.com', 'prod.cosy.bmw.cloud'),
    'Alfa Romeo': ('alfaromeo.it', 'alfaromeo.com', 'media.stellantis.com'),
    'Tesla': ('tesla.com', 'tesla.cn'),
    'BYD': ('byd.com',),
    'Fiat': ('media.stellantis.com', 'fiat.it'),
    'Peugeot': ('peugeot.it', 'media.stellantis.com'),
    'Renault': ('renault.it', 'renault.com'),
    'Volvo': ('volvocars.com',),
    'Ferrari': ('ferrari.com',),
    'Maserati': ('maserati.com',),
    'RAM': ('ramtrucks.com',),
    'Totem': ('totemautomobili.com',),
    'Abarth': ('abarth.it', 'media.stellantis.com'),
    'Citroen': ('citroen.it', 'media.stellantis.com'),
    'DS Automobiles': ('dsautomobiles.it', 'media.stellantis.com'),
    'Jeep': ('jeep-official.it', 'media.stellantis.com'),
    'Lancia': ('lancia.it', 'media.stellantis.com'),
    'Opel': ('opel.it', 'media.stellantis.com'),
    'Leapmotor': ('leapmotor.net',),
    'Toyota': ('toyota.it',),
    'Honda': ('honda.it',),
    'Mazda': ('mazda.it',),
    'Mitsubishi': ('mitsubishi-motors.it',),
    'Range Rover': ('landrover.it',),
    'Discovery': ('landrover.it',),
    'Defender': ('landrover.it',),
}
LIMIT = 32 * 1024 * 1024


def now():
    return datetime.now(timezone.utc).isoformat()


def safe_name(value):
    value = re.sub(r'[^\w.-]+', '_', str(value).strip(), flags=re.UNICODE)
    if not value or value in ('.', '..'):
        raise ValueError('Missing or unsafe brand/model name')
    return value


def atomic_text(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(content, encoding='utf-8')
    temporary.replace(path)


def write_json(path, value):
    atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def write_csv(path, columns, rows):
    text = io.StringIO(newline='')
    writer = csv.DictWriter(text, fieldnames=columns, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)
    atomic_text(path, text.getvalue())


def rows_from_file(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        sample = stream.read(4096)
        stream.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=',;\t')
        except csv.Error:
            dialect = csv.excel
        rows = []
        for raw in csv.DictReader(stream, dialect=dialect):
            normalized = {re.sub(r'[\s-]+', '_', k.strip().lower()): (v or '').strip()
                          for k, v in raw.items() if k}
            aliases = {
                'brand': ('brand', 'marca', 'make', 'manufacturer'),
                'model': ('model', 'modello'),
                'year': ('year', 'anno'),
                'generation': ('generation', 'generazione'),
                'source_page': ('source_page', 'source_url', 'page_url', 'url', 'official_url'),
                'image_url': ('image_url', 'original_image_url', 'image_source_url', 'photo_url'),
                'source_type': ('source_type', 'tipo_fonte'),
                'input_status': ('input_status', 'status'),
                'input_notes': ('input_notes', 'notes', 'note'),
                'input_view': ('input_view', 'view'),
                'handoff_source_page': ('handoff_source_page',),
            }
            row = {key: next((normalized[name] for name in names if normalized.get(name)), '')
                   for key, names in aliases.items()}
            if row['brand'] and row['model']:
                row['year'] = row['year'] or '2026'
                if row['brand'] == 'JAECOO' and 'ambrosispa.it' in row['source_page']:
                    row['source_type'] = 'verified_web_fallback'
                row['input_file'] = str(path)
                rows.append(row)
        if not rows:
            raise ValueError(f'No rows with recognizable brand and model columns: {path}')
        return rows


def official(row, url):
    hostname = (urlparse(url).hostname or '').lower()
    return any(hostname == suffix or hostname.endswith('.' + suffix)
               for suffix in OFFICIAL.get(row['brand'], ()))


def fetch(url, limit=LIMIT):
    if urlparse(url).scheme != 'https':
        raise ValueError('Only verified HTTPS downloads are supported')
    if re.search(r'[\r\n]', url):
        raise ValueError('URL contains a forbidden control character')
    parts = urlsplit(url)
    url = urlunsplit((parts.scheme, parts.netloc,
                     quote(parts.path, safe="/%:@!$&'()*+,;=-._~"),
                     quote(parts.query, safe="=&?/:+,%@!$'()*;~-._"), ''))
    request = Request(url, headers={'User-Agent': 'WrapSimulatorCatalog/1.0',
                                   'Accept': 'text/html,image/jpeg,image/png;q=0.9,*/*;q=0.5'})
    # Use default TLS certificate validation and the configured environment proxy.
    try:
        response = urlopen(request, timeout=25)
    except HTTPError as error:
        if error.code == 503:
            detail = error.read(700).decode('utf-8', errors='replace')
            if 'cloudflare_https_tunnel' in detail and 'upstream connect error' in detail:
                raise URLError('CLOUD_NETWORK_TEMPORARY: HTTP 503 from cloud HTTPS tunnel: ' + detail[:260]) from error
        raise
    with response:
        body = response.read(limit + 1)
        if len(body) > limit:
            raise ValueError('Download exceeds the configured size limit')
        if urlparse(response.geturl()).scheme != 'https':
            raise ValueError('Refusing a redirect from HTTPS to an insecure source')
        return body, response.geturl(), response.headers.get('Content-Type', '')


class SourceImages(HTMLParser):
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.items = []
        self.stack = []
        self.structured_data = None

    def add(self, value, description='', kind='image'):
        if not value or value.startswith('data:'):
            return
        if re.search(r'\.(mp4|webm|mp3|svg|pdf)(\?|$)', value, re.I):
            return
        address = urljoin(self.page, html.unescape(value))
        if urlparse(address).scheme == 'https':
            # Magnolia's image rendition includes the underlying public DAM path.
            # Prefer those original bytes over the cropped, smaller rendition.
            parsed = urlparse(address)
            if parsed.hostname in ('images.porsche.com', 'a.storyblok.com') and '/f/' in parsed.path and '/m/' in parsed.path:
                original = parsed._replace(path=parsed.path.split('/m/',1)[0],query='').geturl()
                if re.search(r'\.(png|jpe?g)$', original, re.I):
                    self.items.append({'url': original, 'caption': description,
                                       'kind': 'original_published_asset', 'discovered_image_url': address})
            # Request a PNG rendition from the manufacturer's own image server.
            # This downloads server-produced bytes; no local conversion/editing.
            if parsed.hostname == 'bmw.scene7.com' and 'fmt=webp' in parsed.query:
                png_query = re.sub(r'fmt=webp(?:-alpha)?', 'fmt=png-alpha', parsed.query)
                self.items.append({'url': parsed._replace(query=png_query).geturl(),
                                   'caption': description, 'kind': 'official_png_rendition',
                                   'discovered_image_url': address})
            if parsed.hostname == 'media.oneweb.mercedes-benz.com' and '/iris.png' in parsed.path and 'Resize' in parsed.query:
                full_query = re.sub(r'([?&])?im=Resize[^&]*', '', parsed.query).strip('&')
                full_query += '&im=Resize,width=1600'
                self.items.append({'url': parsed._replace(query=full_query).geturl(),
                                   'caption': description, 'kind': 'official_png_rendition',
                                   'discovered_image_url': address})
            if parsed.hostname == 'mediaservice.audi.com' and 'mimetype=image' in parsed.query:
                png_query = re.sub(r'mimetype=image(?:%2f|/)webp', 'mimetype=image%2Fpng', parsed.query, flags=re.I)
                png_query = re.sub(r'width=\d+', 'width=1440', png_query)
                self.items.append({'url': parsed._replace(query=png_query).geturl(),
                                   'caption': description, 'kind': 'official_png_rendition',
                                   'discovered_image_url': address})
            if parsed.hostname == 'cdn.ferrari.com' and '/resize/' in parsed.path and 'width=' in parsed.query:
                full_query = re.sub(r'width=\d+', 'width=1600', parsed.query)
                full_query = re.sub(r'&?height=\d+', '', full_query)
                self.items.append({'url': parsed._replace(query=full_query).geturl(),
                                   'caption': description, 'kind': 'official_highres_rendition',
                                   'discovered_image_url': address})
            if parsed.hostname == 'newsroom.porsche.com' and '/.imaging/' in parsed.path and '/dam/' in parsed.path:
                original_path = '/dam/' + re.split(r'/jcr(?::|%3a)content', parsed.path.split('/dam/', 1)[1], flags=re.I)[0]
                self.items.append({'url': 'https://newsroom.porsche.com' + original_path,
                                   'caption': description, 'kind': 'original_dam_asset'})
            self.items.append({'url': address, 'caption': description, 'kind': kind})

    def handle_starttag(self, tag, attrs):
        data = {name: value or '' for name, value in attrs}
        if tag == 'script' and data.get('type') == 'application/ld+json':
            self.structured_data = []
        inherited = next((label for _,label in reversed(self.stack) if label), '')
        caption = data.get('alt', '') or data.get('title', '') or inherited
        if tag == 'meta' and (data.get('property') or data.get('name')) in ('og:image', 'twitter:image'):
            self.add(data.get('content'), kind='social_preview')
        if tag in ('img', 'source'):
            for key in ('src', 'data-src', 'data-original', 'data-image'):
                self.add(data.get(key), caption)
            for key in ('srcset', 'data-srcset'):
                # Image CDN URLs contain commas inside Resize/Crop parameters.
                # Srcset entries are separated after their width/density descriptor.
                srcset = data.get(key, '')
                variants = re.findall(r'(\S+)\s+\d+(?:\.\d+)?[wx](?:\s*,\s*|$)', srcset)
                if not variants and srcset.strip():
                    variants = [srcset.strip()]
                for variant in variants:
                    self.add(variant, caption)
        if tag == 'a' and re.search(r'\.(jpe?g|png)(\?|$)', data.get('href', ''), re.I):
            self.add(data.get('href'), caption, 'download')
        for address in re.findall(r'url\([\s\"\']*([^\)\"\']+)', data.get('style', '')):
            self.add(address.strip(), caption, 'style_image')
        if tag not in ('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'):
            self.stack.append((tag, data.get('title', '') or data.get('aria-label', '')))

    def handle_data(self, value):
        if self.structured_data is not None:
            self.structured_data.append(value)

    def structured_images(self, value, label=''):
        if isinstance(value, list):
            for child in value:
                self.structured_images(child, label)
        elif isinstance(value, dict):
            label = value.get('name', '') or label
            types = value.get('@type', [])
            if isinstance(types, str):
                types = [types]
            if 'ImageObject' in types:
                for key in ('url', 'contentUrl'):
                    address = value.get(key)
                    if isinstance(address, str):
                        self.add(address, label, 'structured_data_image')
            elif isinstance(value.get('image'), str):
                self.add(value['image'], label, 'structured_data_image')
            for child in value.values():
                if isinstance(child, (dict, list)):
                    self.structured_images(child, label)

    def handle_endtag(self, tag):
        if tag == 'script' and self.structured_data is not None:
            try:
                self.structured_images(json.loads(''.join(self.structured_data)))
            except (ValueError, TypeError):
                pass
            self.structured_data = None
        for n in range(len(self.stack)-1, -1, -1):
            if self.stack[n][0] == tag:
                del self.stack[n:]
                break


def row_directory(row):
    return Path(safe_name(row['brand'])) / safe_name(row['model']) / safe_name(row['year']) / 'front_3q_left'


def asset_identity(item):
    """Group responsive renditions without changing any requested source URL."""
    u = urlsplit(item['url'])
    if u.hostname and ('scene7.' in u.hostname or u.hostname in ('mediaservice.audi.com','cdn.ferrari.com','emea-dam.audi.com')):
        return u.scheme, u.netloc, u.path
    if u.hostname == 'media.oneweb.mercedes-benz.com':
        return u.scheme, u.netloc, u.path, tuple((k,v) for k,v in parse_qsl(u.query) if k not in ('im','crop','cp'))
    return item['url']


def discover(row, refresh=False):
    direct = row.get('image_url')
    if direct:
        if not official(row, direct) and row.get('source_type') != 'verified_web_fallback':
            raise ValueError('Nonofficial image needs an explicitly declared verified_web_fallback source')
        parser = SourceImages(row.get('source_page') or direct)
        parser.add(direct, row.get('input_notes', ''), 'supplied_image_url')
        return parser.items
    page = row.get('source_page')
    if not page:
        raise ValueError('No source page or image URL in the supplied catalog row')
    if not official(row, page) and row.get('source_type') != 'verified_web_fallback':
        raise ValueError('Source page is not on a known official domain')
    cache = ROOT / '_CACHE' / (hashlib.sha256(page.encode()).hexdigest() + '.html')
    if cache.exists() and not refresh:
        document = cache.read_text(encoding='utf-8')
        final_page = page
    else:
        body, final_page, _ = fetch(page, limit=8 * 1024 * 1024)
        document = body.decode('utf-8', errors='replace')
        atomic_text(cache, document)
    parser = SourceImages(final_page)
    parser.feed(document)
    unique = {item['url']: item for item in parser.items
              if not any(word in item['url'].casefold()
                         for word in ('placeholder', 'favicon', '/autorenbilder/', '/logo', '/icon'))}
    tokens = [token.casefold() for token in row['model'].replace('_', ' ').split() if len(token) >= 2]
    if row['brand'] == 'Mercedes-Benz' and row['model'].startswith('Classe '):
        letter = row['model'].split()[1].lower()
        tokens = [f'classe {letter}', f'{letter}-class', f'{letter}-klasse']
    if row['brand'] == 'BMW':
        series = re.search(r'Serie[ _]+(\d)', row['model'], re.I)
        if series:
            n = series.group(1)
            tokens = [f'{n} series', f'{n}-series', f'serie {n}']
    rejected_path = ROOT / '_REPORTS' / 'REJECTED_ASSET_URLS.json'
    rejected = json.loads(rejected_path.read_text()) if rejected_path.exists() else {}
    unique = {url:item for url,item in unique.items() if url not in rejected}

    def score(item):
        text = (item['caption'] + ' ' + item['url']).casefold()
        return (sum(40 for token in tokens if re.search(r'(?<![a-z0-9])' + re.escape(token) + r'(?![a-z0-9])', text))
                + (5 if item['kind'] == 'download' else 0)
                + (15 if item['kind'] == 'original_dam_asset' else 0)
                + (15 if item['kind'] == 'original_published_asset' else 0)
                + (15 if item['kind'] == 'structured_data_image' else 0)
                + (35 if 'studio' in text else 0)
                + (4 if item['kind'] == 'official_png_rendition' else 0)
                + (6 if item['kind'] == 'official_highres_rendition' else 0)
                - (50 if 'walkaround' in text else 0)
                - sum(40 for word in ('logo', 'icon', 'interior', 'cockpit', 'steering', 'mbux', 'close-up', 'headlight', 'grille', 'superscreen') if word in text))

    result = []
    seen = set()
    for item in sorted(unique.values(), key=score, reverse=True):
        identity = asset_identity(item)
        if identity not in seen:
            seen.add(identity)
            result.append(item)
    return result


def candidate_download(row, candidate, directory):
    url = candidate['url']
    decisions_path = ROOT / '_REPORTS' / 'REJECTED_MODEL_ASSETS.json'
    if decisions_path.exists():
        decisions = json.loads(decisions_path.read_text())
        decision_key = json.dumps([safe_name(row['brand']).casefold(), safe_name(row['model']).casefold(), str(row['year']), url], ensure_ascii=False)
        if decision_key in decisions:
            raise ValueError('Previously rejected for this model: ' + decisions[decision_key]['rejection_reason'])
    stem = hashlib.sha256(url.encode()).hexdigest()[:16]
    metadata_path = directory / (stem + '.json')
    if metadata_path.exists():
        metadata = json.loads(metadata_path.read_text())
        if metadata.get('verification_status') in ('REJECTED_FOR_CATALOG', 'REJECTED_VISUAL_REVIEW'):
            raise ValueError('Previously rejected during visual review: ' + metadata.get('rejection_reason', ''))
        existing = directory / metadata['candidate_file']
        if existing.exists() and hashlib.sha256(existing.read_bytes()).hexdigest() == metadata['sha256']:
            return metadata
    body, final_url, content_type = fetch(url)
    with Image.open(io.BytesIO(body)) as image:
        dimensions = image.size
        image_format = image.format
        image.verify()
    if image_format not in ('JPEG', 'PNG'):
        raise ValueError(f'Original format {image_format} is not JPEG/PNG; no conversion performed')
    if dimensions[0] < 1000 or dimensions[1] < 500:
        raise ValueError(f'Insufficient resolution for a source photograph: {dimensions}')
    suffix = '.jpg' if image_format == 'JPEG' else '.png'
    asset = directory / (stem + suffix)
    directory.mkdir(parents=True, exist_ok=True)
    temporary = asset.with_name(asset.name + '.writing')
    temporary.write_bytes(body)
    temporary.replace(asset)
    metadata = {
        **row, 'view': 'front_3q_left', 'view_verified': False,
        'source_page': row.get('source_page', ''), 'image_url': url,
        'resolved_image_url': final_url, 'source_type': row.get('source_type') or 'official',
        'image_host_is_official': official(row, final_url),
        'download_date': now(), 'image_dimensions': {'width': dimensions[0], 'height': dimensions[1]},
        'sha256': hashlib.sha256(body).hexdigest(), 'candidate_file': asset.name,
        'content_type': content_type, 'source_caption': candidate['caption'],
        'discovered_image_url': candidate.get('discovered_image_url', url),
        'verification_status': 'PENDING_VISUAL_REVIEW',
        'year_basis': 'catalog_edition; model year must be visually or editorially verified',
        'notes': 'Downloaded original image. Model, generation and view are not yet visually approved.',
    }
    write_json(metadata_path, metadata)
    return metadata


def download(rows, max_candidates, refresh=False):
    state = ROOT / '_REPORTS' / 'DOWNLOAD_STATE.json'
    existing = json.loads(state.read_text()) if state.exists() else []
    outcomes = {(row['brand'], row['model'], str(row['year'])): row for row in existing}
    count = 0
    blocked_hosts = {}
    for row in rows:
        approved = ROOT / row_directory(row) / 'source.json'
        if approved.exists():
            metadata = json.loads(approved.read_text())
            original = approved.parent / metadata['source_original']
            if original.is_file() and hashlib.sha256(original.read_bytes()).hexdigest() == metadata['sha256']:
                print(f"{row['brand']} {row['model']}: preserved existing verified original", flush=True)
                continue
        directory = ROOT / '_CANDIDATES' / row_directory(row)
        selected = []
        errors = []
        try:
            host = urlparse(row.get('image_url') or row.get('source_page') or '').hostname
            if host in blocked_hosts:
                raise ValueError('BLOCKED_NETWORK: proxy denied host ' + host)
            candidates = discover(row, refresh)
            for candidate in candidates[:16]:
                try:
                    image_host = urlparse(candidate['url']).hostname
                    if image_host in blocked_hosts:
                        raise ValueError('BLOCKED_NETWORK: proxy denied image host ' + image_host)
                    selected.append(candidate_download(row, candidate, directory))
                    if len(selected) >= max_candidates:
                        break
                except (HTTPError, URLError, TimeoutError, OSError, ValueError, HTTPException) as error:
                    errors.append(urlparse(candidate['url']).hostname + ': ' + str(error)[:250])
                    if 'Tunnel connection failed' in str(error):
                        blocked_hosts[urlparse(candidate['url']).hostname] = str(error)
            if not selected:
                raise ValueError('No suitable photograph downloaded. ' + '; '.join(errors[:3]))
            status = 'PENDING_VISUAL_REVIEW'
            reason = ''
            count += len(selected)
            print(f"{row['brand']} {row['model']}: {len(selected)} downloaded candidate image file(s), pending visual review", flush=True)
        except (HTTPError, URLError, TimeoutError, OSError, ValueError, HTTPException) as error:
            status = 'BLOCKED_NETWORK' if any(x in str(error) for x in ('Tunnel connection failed', 'BLOCKED_NETWORK', 'CLOUD_NETWORK_TEMPORARY')) else 'SOURCE_FETCH_FAILED'
            reason = str(error)[:500]
            if isinstance(error, URLError) and 'Tunnel connection failed' in str(error) and host:
                blocked_hosts.setdefault(host, 'proxy denied host ' + host)
            print(f"{row['brand']} {row['model']}: {status}: {reason}", file=sys.stderr, flush=True)
        outcomes[(row['brand'], row['model'], str(row['year']))] = {
            **row, 'status': status, 'candidate_count': len(selected),
            'reason': reason, 'checked_at': now()}
        # Save after every model so an interruption retains useful progress.
        write_json(state, list(outcomes.values()))
        reports(list(outcomes.values()))
    return count


def approve(candidate, generation, actual_view, notes, transparent_original=False, update_reports=True):
    candidate = candidate.resolve()
    if not candidate.is_relative_to(ROOT / '_CANDIDATES'):
        raise ValueError('Approval must refer to a downloaded candidate within this catalog')
    metadata = json.loads(candidate.with_suffix('.json').read_text())
    destination = ROOT / row_directory(metadata)
    if (destination / 'source.json').exists():
        raise ValueError('An original already exists; preserve it and review explicitly before replacing')
    with Image.open(candidate) as image:
        image.verify()
    if hashlib.sha256(candidate.read_bytes()).hexdigest() != metadata['sha256']:
        raise ValueError('Candidate checksum does not match recorded downloaded bytes')
    destination.mkdir(parents=True, exist_ok=True)
    original = destination / ('source_original' + candidate.suffix)
    shutil.copyfile(candidate, original)
    metadata.update({
        'generation': generation or metadata.get('generation') or None,
        'view': actual_view, 'requested_view': 'front_3q_left', 'view_verified': True,
        'verification_status': 'VISUALLY_VERIFIED_ORIGINAL',
        'status': 'NEEDS_MASK_REVIEW', 'source_original': original.name,
        'notes': notes, 'visually_verified_at': now(),
        'transparent': False, 'mask_wrap': False, 'mask_exclusions': False, 'preview': False,
    })
    if transparent_original:
        with Image.open(candidate) as image:
            if image.format != 'PNG' or 'A' not in image.getbands() or image.getchannel('A').getextrema() != (0, 255):
                raise ValueError('An original transparent PNG with actual opaque and transparent pixels is required')
        # Exact byte copies of a visually inspected manufacturer's cutout, no image editing.
        shutil.copyfile(candidate, destination / 'vehicle_transparent.png')
        shutil.copyfile(candidate, destination / 'preview.png')
        metadata.update({'transparent': True, 'preview': True,
                         'transparent_origin': 'manufacturer_supplied_png; unchanged bytes',
                         'preview_type': "unchanged manufacturer's transparent source; no wrap simulation",
                         'transparent_sha256': metadata['sha256'], 'preview_sha256': metadata['sha256']})
    write_json(destination / 'source.json', metadata)
    if update_reports:
        reports()
    print(f'Preserved verified original: {original}')


def reports(outcomes=None):
    if outcomes is None:
        state = ROOT / '_REPORTS' / 'DOWNLOAD_STATE.json'
        outcomes = json.loads(state.read_text()) if state.exists() else []
    # Export model-specific visual decisions so progressive ZIPs retain them on resume.
    decisions_path = ROOT / '_REPORTS' / 'REJECTED_MODEL_ASSETS.json'
    decisions = json.loads(decisions_path.read_text()) if decisions_path.exists() else {}
    for candidate in (ROOT / '_CANDIDATES').glob('*/*/*/*/*.json'):
        metadata = json.loads(candidate.read_text())
        if metadata.get('verification_status') in ('REJECTED_FOR_CATALOG', 'REJECTED_VISUAL_REVIEW'):
            decision_key = json.dumps([safe_name(metadata['brand']).casefold(), safe_name(metadata['model']).casefold(), str(metadata['year']), metadata['image_url']], ensure_ascii=False)
            decisions[decision_key] = {name: metadata.get(name,'') for name in ('brand','model','year','image_url','rejection_reason','visually_reviewed_at')}
    write_json(decisions_path, decisions)
    def catalog_key(row):
        return (safe_name(row['brand']).casefold(), safe_name(row['model']).casefold(), str(row['year']))
    baseline = ROOT / '_QUEUE' / 'HANDOFF_MERGED.csv'
    baseline_rows = rows_from_file(baseline) if baseline.exists() else []
    baseline_keys = {catalog_key(row) for row in baseline_rows}
    progress = []
    review = []
    missing = []
    indexed = set()
    for source in sorted(ROOT.glob('*/*/*/*/source.json')):
        metadata = json.loads(source.read_text())
        directory = source.parent
        key = catalog_key(metadata)
        indexed.add(key)
        row = {key: metadata[key] for key in ('brand', 'model', 'year')}
        row['source_original'] = str((directory / metadata['source_original']).relative_to(ROOT))
        for key, filename in (('transparent', 'vehicle_transparent.png'), ('mask_wrap', 'mask_wrap.png'),
                              ('mask_exclusions', 'mask_exclusions.png'), ('preview', 'preview.png')):
            row[key] = str((directory / filename).relative_to(ROOT)) if (directory / filename).is_file() else ''
        row['status'] = metadata.get('status', 'NEEDS_MASK_REVIEW')
        progress.append(row)
        if row['status'] != 'READY':
            review.append({**row, 'reason': metadata.get('notes', ''), 'source_page': metadata['source_page']})
    for outcome in outcomes:
        key = catalog_key(outcome)
        if key in indexed or (baseline_keys and key not in baseline_keys):
            continue
        indexed.add(key)
        row = {name: outcome.get(name, '') for name in ('brand', 'model', 'year', 'status')}
        reason = outcome.get('reason', '')
        candidates = []
        for candidate in (ROOT / '_CANDIDATES' / row_directory(outcome)).glob('*.json'):
            candidate_metadata = json.loads(candidate.read_text())
            if candidate_metadata.get('verification_status') not in ('REJECTED_FOR_CATALOG', 'REJECTED_VISUAL_REVIEW'):
                candidates.append(candidate_metadata)
        if candidates:
            row['status'] = 'PENDING_VISUAL_REVIEW'
            reason = 'Downloaded candidates await visual verification.' + (' Last retrieval attempt: ' + reason if reason else '')
        elif row['status'] == 'PENDING_VISUAL_REVIEW':
            row['status'] = 'NEEDS_SOURCE_REVIEW'
            reason = 'All downloaded candidates were rejected during visual review; retain handoff source and seek another image.'
        if outcome['model'].casefold() == 'taycan family':
            row['status'] = 'REFERENCE_ONLY'
            reason = 'Handoff family reference; individual Taycan, Cross Turismo and Sport Turismo remain separate model records.'
        progress.append(row)
        review.append({**row, 'reason': reason or 'Candidate photographs await visual verification',
                       'source_page': outcome.get('source_page', '')})
        if row['status'] not in ('PENDING_VISUAL_REVIEW', 'REFERENCE_ONLY'):
            missing.append({**row, 'source_page': outcome.get('source_page', ''),
                            'reason': reason,
                            'official_source_missing_confirmed': 'false'})
    # Preserve every supplied model in progress, including work not yet attempted.
    if baseline_rows:
        for row in baseline_rows:
            key = catalog_key(row)
            if key not in indexed:
                progress.append({'brand': row['brand'], 'model': row['model'], 'year': row['year'],
                                 'status': 'QUEUED'})
    write_csv(ROOT / '_REPORTS' / 'IMAGE_PROGRESS.csv',
              ['brand','model','year','source_original','transparent','mask_wrap','mask_exclusions','preview','status'], progress)
    write_csv(ROOT / '_REPORTS' / 'NEEDS_REVIEW.csv',
              ['brand','model','year','status','reason','source_page'], review)
    write_csv(ROOT / '_REPORTS' / 'MISSING_OFFICIAL_SOURCES.csv',
              ['brand','model','year','status','source_page','reason','official_source_missing_confirmed'], missing)


ARCHIVE_GROUPS = {
    '01_GERMAN_PREMIUM': ('Porsche', 'Mercedes-Benz', 'Audi', 'BMW'),
    '02_ITALIAN_LUXURY': ('Ferrari', 'Lamborghini', 'Maserati', 'Alfa Romeo', 'Lancia', 'Totem', 'Pagani'),
    '03_STELLANTIS_EUROPE': ('Fiat', 'Abarth', 'Peugeot', 'Citroen', 'DS Automobiles', 'Jeep', 'Opel', 'Leapmotor', 'Renault'),
    '04_UK_LUXURY': ('Range Rover', 'Discovery', 'Defender', 'Land Rover', 'Bentley', 'Rolls-Royce', 'Aston Martin', 'McLaren', 'Lotus', 'Jaguar'),
    '05_ASIA': ('Toyota', 'Honda', 'Mazda', 'Mitsubishi', 'BYD', 'JAECOO', 'Lexus', 'Genesis', 'Infiniti'),
    '06_OTHER_BRANDS': ('Volvo', 'Tesla', 'RAM'),
}


def archive(group='01_GERMAN_PREMIUM'):
    sources = []
    for brand in ARCHIVE_GROUPS[group]:
        sources.extend(sorted((ROOT / safe_name(brand)).glob('*/*/*/source.json')))
    if not sources:
        raise ValueError('No visually verified original photographs exist: refusing an empty/CSV-only ZIP')
    output = ROOT / ('WRAPSIM_CATALOG_' + group + '.zip')
    temporary = output.with_name(output.name + '.writing')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as zipped:
        for source in sources:
            metadata = json.loads(source.read_text())
            original = source.parent / metadata['source_original']
            if hashlib.sha256(original.read_bytes()).hexdigest() != metadata['sha256']:
                raise ValueError(f'Original checksum mismatch: {original}')
            with Image.open(original) as image:
                image.verify()
            for asset in sorted(source.parent.iterdir()):
                if asset.is_file() and asset.name in {
                    metadata['source_original'], 'source.json', 'vehicle_transparent.png',
                    'mask_wrap.png', 'mask_exclusions.png', 'preview.png'}:
                    zipped.write(asset, asset.relative_to(ROOT))
        for report in sorted((ROOT / '_REPORTS').glob('*.csv')):
            zipped.write(report, report.relative_to(ROOT))
        # Include the supplied baseline and reproducible working instructions in every batch.
        # Candidate images stay outside the deliverable until actual visual approval.
        for folder, pattern in (('_HANDOFF', '*.csv'), ('_QUEUE', '*.csv'), ('_TOOLS', '*.py')):
            for file in sorted((ROOT / folder).glob(pattern)):
                zipped.write(file, file.relative_to(ROOT))
        for name in ('README.md',):
            file = ROOT / name
            if file.is_file():
                zipped.write(file, name)
        for name in ('HANDOFF_IMPORT.json', 'PUBLISHED_MODEL_PAGE_PROVENANCE.json', 'REJECTED_ASSET_URLS.json',
                     'REJECTED_MODEL_ASSETS.json', 'DOWNLOAD_STATE.json', 'NETWORK_DIAGNOSTICS.json', 'INTEGRITY_AUDIT.json'):
            file = ROOT / '_REPORTS' / name
            if file.is_file():
                zipped.write(file, file.relative_to(ROOT))
        from review_gallery import render
        zipped.writestr('review.html', render(sources, 'Wrap Simulator — ' + group))
    with zipfile.ZipFile(temporary) as zipped:
        bad_file = zipped.testzip()
        if bad_file:
            raise ValueError(f'Archive integrity check failed: {bad_file}')
    temporary.replace(output)
    write_json(ROOT / '_REPORTS' / ('ARCHIVE_' + group + '.json'), {
        'created_at': now(), 'file': output.name, 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
        'verified_originals': len(sources), 'status': 'PROGRESSIVE; consult per-model status; catalog not complete',
        'models': [str(p.relative_to(ROOT)) for p in sources]})
    print(f'{output}: {len(sources)} visually verified original image(s); consult mask review status')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    downloader = commands.add_parser('download')
    downloader.add_argument('--input', type=Path, action='append', required=True)
    downloader.add_argument('--max-candidates', type=int, default=3)
    downloader.add_argument('--refresh-pages', action='store_true')
    approval = commands.add_parser('approve', help='Run only after actual visual inspection of the photograph')
    approval.add_argument('candidate', type=Path)
    approval.add_argument('--generation', default='')
    approval.add_argument('--view', default='front_3q_left')
    approval.add_argument('--notes', required=True)
    approval.add_argument('--transparent-original', action='store_true', help='Only for a visually verified manufacturer-supplied transparent PNG; copies original bytes')
    commands.add_parser('report')
    zipper = commands.add_parser('zip')
    zipper.add_argument('--group', choices=ARCHIVE_GROUPS, default='01_GERMAN_PREMIUM')
    args = parser.parse_args()
    try:
        if args.command == 'download':
            rows = {}
            for filename in args.input:
                for row in rows_from_file(filename):
                    key = (row['brand'], row['model'], row['year'])
                    # Prefer batch files with direct image URLs over page-only records.
                    if key not in rows or row.get('image_url'):
                        rows[key] = row
            return 0 if download(list(rows.values()), max(1, args.max_candidates), args.refresh_pages) else 2
        if args.command == 'approve':
            approve(args.candidate, args.generation, args.view, args.notes, args.transparent_original)
        elif args.command == 'report':
            reports()
        elif args.command == 'zip':
            archive(args.group)
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        print(f'Catalog error: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
