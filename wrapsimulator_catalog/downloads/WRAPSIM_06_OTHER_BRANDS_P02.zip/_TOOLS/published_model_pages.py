#!/usr/bin/env python3
"""Follow model links already published on supplied official pages, retaining the handoff."""
import hashlib
import re
import unicodedata
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit, unquote
import catalog


def normalize(value):
    value = unicodedata.normalize('NFKD', unquote(value)).encode('ascii', 'ignore').decode().lower()
    return ' '.join(re.findall(r'[a-z0-9]+', value))


class Links(HTMLParser):
    def __init__(self, page):
        super().__init__()
        self.page, self.links, self.active = page, [], None

    def handle_starttag(self, tag, attrs):
        data = dict(attrs)
        if tag == 'a' and data.get('href'):
            self.active = [urljoin(self.page, data['href']), data.get('title') or data.get('aria-label') or '']
        elif tag == 'img' and self.active and data.get('alt'):
            self.active[1] += ' ' + data['alt']

    def handle_data(self, data):
        if self.active:
            self.active[1] += ' ' + data

    def handle_endtag(self, tag):
        if tag == 'a' and self.active:
            self.links.append(self.active)
            self.active = None


def main():
    rows = catalog.rows_from_file(catalog.ROOT / '_QUEUE' / 'HANDOFF_MERGED.csv')
    result, provenance, parsed = [], [], {}
    for row in rows:
        if (catalog.ROOT / catalog.row_directory(row) / 'source.json').exists():
            continue
        page = row['source_page']
        cache = catalog.ROOT / '_CACHE' / (hashlib.sha256(page.encode()).hexdigest() + '.html')
        if not cache.exists() or not catalog.official(row, page):
            continue
        if page not in parsed:
            parser = Links(page)
            parser.feed(cache.read_text())
            parsed[page] = parser.links
        wanted = normalize(row['model'])
        brand = normalize(row['brand'])
        if row['brand'] == 'Toyota' and wanted.startswith(brand + ' '):
            wanted = wanted[len(brand)+1:]
        options = []
        for address, caption in parsed[page]:
            u = urlsplit(address)
            if u.scheme != 'https' or not catalog.official(row, address) or address.split('#')[0] == page:
                continue
            if re.search(r'\.(jpg|jpeg|png|pdf|svg|mp4|xlsx|docx)(\?|$)', address, re.I):
                continue
            path, label = normalize(u.path), normalize(caption)
            match = r'(?<![a-z0-9])' + re.escape(wanted) + r'(?![a-z0-9])'
            if not wanted or not (re.search(match, path) or re.search(match, label)):
                continue
            # Long navigation captions can mention unrelated models: only trust
            # them if the URL itself also matches the requested name.
            if len(label.split()) > 10 and not re.search(match, path):
                continue
            if any(word in u.netloc + path for word in ('configurator', 'store.', 'mynext.', 'selector', 'search')):
                continue
            # A broad family name must not pick another supplied body/model.
            other_names = [normalize(other['model']) for other in rows if other['brand']==row['brand'] and other['model']!=row['model']]
            if any(name.startswith(wanted+' ') and (re.search(r'(?<![a-z0-9])'+re.escape(name)+r'(?![a-z0-9])', path) or label==name) for name in other_names):
                continue
            penalty = sum(100 for word in ('configur', 'offert', 'accessor', 'finanzi', 'usato', 'test drive', 'pdf', 'business', 'tutorial') if word in path)
            penalty += 50 if 'amg' in path and 'amg' not in wanted else 0
            priority = (200 if label in (wanted, brand + ' ' + wanted, 'nuovo ' + wanted, 'nuova ' + wanted) else 0) + (80 if re.search(match,path) else 0) - penalty
            options.append((priority, -len(address), address.split('#')[0], caption.strip()))
        if options:
            _, _, address, caption = max(options)
            row['source_page'] = address
            row['handoff_source_page'] = page
            row['image_url'] = ''
            result.append(row)
            provenance.append({'brand':row['brand'], 'model':row['model'], 'handoff_source_page':page,
                               'published_model_link':address, 'anchor_text':caption, 'discovered_at':catalog.now()})
    catalog.write_csv(catalog.ROOT / '_QUEUE' / 'PUBLISHED_MODEL_PAGES.csv',
                      ['brand','model','year','source_page','image_url','source_type','handoff_source_page','input_status','input_notes','input_view'], result)
    catalog.write_json(catalog.ROOT / '_REPORTS' / 'PUBLISHED_MODEL_PAGE_PROVENANCE.json', provenance)
    print(f'{len(result)} model-specific links found on existing official source pages')
    for row in result:
        print(row['brand'], row['model'], row['source_page'])


if __name__ == '__main__':
    main()
