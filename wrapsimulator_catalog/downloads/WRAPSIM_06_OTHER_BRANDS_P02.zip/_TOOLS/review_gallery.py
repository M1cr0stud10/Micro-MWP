#!/usr/bin/env python3
"""Create an offline review page linking to unchanged, visually verified assets."""
import html
import json
from urllib.parse import quote

import catalog


def render(sources, title='Wrap Simulator — originali verificati'):
    cards = []
    for source in sorted(sources):
        data = json.loads(source.read_text())
        folder = source.parent.relative_to(catalog.ROOT)
        name = data['brand'] + ' ' + data['model']
        original = quote(str(folder / data['source_original']))
        native = bool(data.get('transparent'))
        dimensions = data['image_dimensions']
        image_link = quote(str(folder / 'vehicle_transparent.png')) if native else original
        esc = lambda value: html.escape(str(value), quote=True)
        cards.append(f'''<article data-search="{esc(name.casefold())}" data-native="{str(native).lower()}">
<a href="{image_link}"><img src="{image_link}" alt="{esc(name)}" loading="lazy"></a>
<div class="info"><h2>{esc(name)}</h2>
<p>{esc(data['view'])} · {dimensions['width']} × {dimensions['height']} · {"PNG trasparente nativo" if native else "Originale con sfondo"}</p>
<p class="status">Maschere da revisionare · NEEDS_MASK_REVIEW</p>
<p><a href="{original}">Originale</a> · <a href="{quote(str(folder / 'source.json'))}">Metadati</a> · <a href="{esc(data['source_page'])}">Fonte</a></p>
<details><summary>Note di verifica</summary><p>{esc(data.get('notes',''))}</p></details></div></article>''')
    return '''<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>''' + html.escape(title) + '''</title><style>
body{font:16px system-ui,sans-serif;background:#f4f5f7;color:#192431;margin:0}header{padding:28px;max-width:1500px;margin:auto}h1{margin-top:0}input,select{font:inherit;padding:10px;border:1px solid #aeb6c1;border-radius:6px}input{width:min(440px,90%)}main{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;padding:0 28px 28px;max-width:1500px;margin:auto}article{background:white;border-radius:10px;overflow:hidden;border:1px solid #d9dee5}article[hidden]{display:none}img{width:100%;height:230px;object-fit:contain;background:repeating-conic-gradient(#e6e9ec 0% 25%,#fafafa 0% 50%) 50%/24px 24px}.info{padding:18px}h2{font-size:18px;margin-top:0}p{line-height:1.45;font-size:14px}a{color:#154a83}.status{color:#805000}details p{font-size:13px}label{display:inline-block;margin:5px 10px 5px 0}
</style><header><h1>''' + html.escape(title) + f'''</h1>
<p>Lotto progressivo: {len(sources)} originali verificati. Le immagini includono fotografie e render pubblicati dai costruttori. Maschere wrap ed esclusioni ancora assenti; nessuna simulazione wrap.</p>
<p>2026 indica l’edizione del catalogo. La vista effettiva e le limitazioni sono registrate nei metadati di ogni modello.</p>
<label>Cerca marca o modello <input id="search" type="search" placeholder="BMW, Taycan, EQS…"></label>
<label>Disponibilità <select id="native"><option value="all">Tutti gli originali</option><option value="true">Con PNG trasparente nativo</option><option value="false">Con sfondo</option></select></label><p id="count">{len(sources)} modelli</p></header><main>''' + ''.join(cards) + '''</main><script>
const cards=[...document.querySelectorAll('article')],search=document.getElementById('search'),native=document.getElementById('native');
function filter(){let count=0;for(const card of cards){const show=card.dataset.search.includes(search.value.toLocaleLowerCase('it'))&&(native.value==='all'||card.dataset.native===native.value);card.hidden=!show;if(show)count++;}document.getElementById('count').textContent=count+' modelli';}
search.addEventListener('input',filter);native.addEventListener('change',filter);
</script></html>'''


if __name__ == '__main__':
    catalog.atomic_text(catalog.ROOT / 'review.html', render(list(catalog.ROOT.glob('*/*/*/*/source.json'))))
