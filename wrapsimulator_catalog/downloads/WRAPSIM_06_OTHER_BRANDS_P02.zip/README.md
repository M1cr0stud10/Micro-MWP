# Wrap Simulator — catalogo immagini 2026

Lotto progressivo costruito a partire da `WRAPSIM_CODEX_HANDOFF.zip`, preservando i sei CSV originali in `_HANDOFF/`. La baseline unificata contiene 281 record; i batch sorgente sono stati integrati nel catalogo espanso senza ripartire da zero. I checksum dell’importazione sono in `_REPORTS/HANDOFF_IMPORT.json`.

## Stato del lotto

Sono presenti **170 originali controllati visivamente**, con `source.json`: 164 modelli della baseline e 6 varianti aggiuntive verificate. **55 modelli** hanno un PNG trasparente già pubblicato dal costruttore, copiato senza modifiche in `vehicle_transparent.png` e `preview.png`.

**Le maschere `mask_wrap.png` e `mask_exclusions.png` sono ancora assenti. Tutti i 170 asset conservati hanno stato `NEEDS_MASK_REVIEW`.** Le preview disponibili sono copie del PNG nativo: non mostrano una simulazione di wrapping. Il lotto non è pronto per l’importazione come catalogo completo del simulatore. Restano 116 record della baseline senza un originale approvato e un record di riferimento (famiglia Taycan): 80 richiedono ulteriori verifiche di download/fonte e 36 una nuova selezione della fonte. Nessun asset è `READY`.

| ZIP progressivo | Originali verificati |
| --- | ---: |
| `WRAPSIM_CATALOG_01_GERMAN_PREMIUM.zip` | 94 |
| `WRAPSIM_CATALOG_02_ITALIAN_LUXURY.zip` | 24 |
| `WRAPSIM_CATALOG_03_STELLANTIS_EUROPE.zip` | 13 |
| `WRAPSIM_CATALOG_04_UK_LUXURY.zip` | 3 |
| `WRAPSIM_CATALOG_05_ASIA.zip` | 19 |
| `WRAPSIM_CATALOG_06_OTHER_BRANDS.zip` — Volvo, Tesla, RAM | 17 |

Ogni ZIP contiene immagini, metadati, report CSV, baseline originale, code derivate e strumenti di lavoro. Contiene anche una `review.html` limitata ai modelli presenti nel pacchetto. Estrarre i pacchetti nella stessa cartella permette di riunire i gruppi; i file condivisi coincidono. Nel workspace, `review.html` mostra tutti gli originali con ricerca per marca/modello e filtro per PNG trasparente.

## Struttura e provenienza

Gli asset approvati sono in `Marca/Modello/2026/front_3q_left/`. Il percorso mantiene la vista richiesta dall’handoff; **la vista effettiva è il campo `view` di `source.json`**, e può essere frontale, laterale o tre quarti destra. Nessuna immagine è stata specchiata per cambiare il lato.

`source.json` conserva pagina fonte, URL immagine scoperto e scaricato, URL risolto, data del download, dimensioni, checksum SHA-256, modello, generazione quando identificabile, vista effettiva e note del controllo. Il campo `handoff` conserva separatamente le dichiarazioni della baseline. Il valore `2026` indica l’edizione del catalogo, non certifica il model year del veicolo: alcuni asset ufficiali pubblicati oggi hanno percorsi riferiti al 2027. Una generazione nulla richiede verifica editoriale prima di usare l’asset per una generazione specifica. Austral I pre-restyling e Clio V restyling sono fonti storiche esplicitamente identificate: non devono essere importate come immagini del restyling Austral o di Clio VI. Alcune fotografie mostrano la vettura piccola nel paesaggio: i limiti sono indicati nelle note del singolo modello.

Le fonti includono fotografie e render di prodotto pubblicati dai costruttori. Gli originali sono rimasti invariati. I PNG trasparenti conservano anche eventuali ombre native; non equivalgono a una maschera dei soli pannelli verniciati. Le richieste di rendizioni JPEG/PNG di maggiore risoluzione usano i server di immagini del costruttore; i parametri e gli URL rimangono nei metadati. Non sono state usate API immagini a pagamento o immagini generate.

## Report e lavoro residuo

- `_REPORTS/IMAGE_PROGRESS.csv`: tutti i 281 record ricevuti e le 6 varianti aggiuntive approvate, senza duplicati di nome normalizzato.
- `_REPORTS/NEEDS_REVIEW.csv`: attività ancora necessarie, comprese mascheratura, selezione della fonte e problemi di download.
- `_REPORTS/MISSING_OFFICIAL_SOURCES.csv`: problemi di reperimento da investigare. `official_source_missing_confirmed=false` distingue un download fallito da una fonte ufficiale dimostrata assente.
- `_REPORTS/NETWORK_DIAGNOSTICS.json`: errori HTTP 503 del tunnel HTTPS cloud, osservati su più costruttori; i tentativi con evidenza del guasto sono stati registrati come `BLOCKED_NETWORK`. Dopo il recupero, le code sono state riprovate e lo stato corrente riflette i nuovi risultati. Nessun record del report finale rimane `BLOCKED_NETWORK`; gli errori storici del tunnel sono conservati senza dichiarare assenti le fonti ufficiali.
- `_REPORTS/ASSET_MANIFEST.csv` e `INTEGRITY_AUDIT.json`: inventario e verifica dei file reali consegnati.
- `_REPORTS/ARCHIVE_*.json`: checksum e modelli di ogni ZIP.

I candidati scaricati sono in `_CANDIDATES/` e restano fuori dagli ZIP finché non sono approvati visivamente. I rifiuti hanno motivo e data nel JSON del candidato. Sono stati scartati modelli sbagliati, loghi, interni, gruppi di vetture, fotografie tagliate, immagini con occlusioni e sorgenti degradati. Le pagine ufficiali specifiche in `_QUEUE/PUBLISHED_MODEL_PAGES.csv` provengono dai collegamenti presenti nelle pagine già fornite dall’handoff; la traccia è in `_REPORTS/PUBLISHED_MODEL_PAGE_PROVENANCE.json`.

I pacchetti conservano anche `DOWNLOAD_STATE.json` e `REJECTED_MODEL_ASSETS.json`: i tentativi di reperimento e i rifiuti specifici per modello restano disponibili dopo l’estrazione, anche senza le immagini candidate scartate.

Il servizio di segmentazione del server Microstudio non è accessibile da questo workspace; non sono state invocate API a pagamento. Per gli asset non mascherabili qui è stato applicato il fallback autorizzato: originale e metadati preservati, PNG nativo quando disponibile, stato `NEEDS_MASK_REVIEW` e passaggio al modello seguente. Per completare gli asset servono scontorno dei rimanenti originali e maschere revisionate della stessa dimensione dell’immagine. La maschera wrap deve comprendere i soli pannelli verniciati idonei; vetri, fari, griglie, cerchi, pneumatici, badge, targhe, cromature, plastiche grezze e carbonio devono essere esclusi. Il Cybertruck richiede una decisione specifica sui pannelli inox non verniciati. Nessun modello deve diventare `READY` finché le maschere e una vera preview di wrapping non sono validate.

## Ripresa del lavoro

Gli strumenti usano Python 3 e Pillow già disponibili nell’ambiente. Eseguire dalla cartella del catalogo:

```bash
# Riprende la baseline e conserva gli originali approvati, verificandone il checksum.
python3 _TOOLS/catalog.py download --input _QUEUE/HANDOFF_DOWNLOAD_ORDER.csv --max-candidates 2

# Usa le pagine specifiche già individuate; nessuna approvazione automatica.
python3 _TOOLS/catalog.py download --input _QUEUE/PUBLISHED_MODEL_PAGES.csv --max-candidates 2

# Riprova soltanto gli errori temporanei delle pagine specifiche, con 4 richieste concorrenti.
python3 _TOOLS/retry_candidates.py --input _QUEUE/PUBLISHED_MODEL_PAGES.csv --temporary-failures-only

python3 _TOOLS/catalog.py report
python3 _TOOLS/review_gallery.py
python3 _TOOLS/audit_catalog.py
python3 _TOOLS/catalog.py zip --group 01_GERMAN_PREMIUM
```

Aprire realmente il candidato prima di eseguire `catalog.py approve`; registrare generazione, vista effettiva e limiti nelle note. `--transparent-original` si applica soltanto a PNG del costruttore con canale alfa verificato. I downloader non sovrascrivono un originale approvato. Eseguire un solo downloader che scrive lo stato condiviso alla volta.

Il workspace cloud non è il server Microstudio. L’endpoint di produzione indicato nell’handoff (`http://127.0.0.1:8091/wrap-ai/health`) è locale a quel server; qui non è disponibile un accesso a quel servizio. Nessun container o file del server è stato modificato. Il repository Micro-DNA è rimasto invariato; il lavoro è confinato alla cartella del catalogo. La bozza della configurazione di rete cloud è stata salvata per le fonti usate, senza pubblicazione della configurazione.
